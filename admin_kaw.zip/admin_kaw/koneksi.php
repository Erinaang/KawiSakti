<?php
$host		= "localhost";
$user		= "root";
$password	= "";
$database	= "db_kawi";
$connect	= mysqli_connect($host, $user, $password, $database) or die ("GAGAL TERHUBUNG KE DATABASE!!!");
